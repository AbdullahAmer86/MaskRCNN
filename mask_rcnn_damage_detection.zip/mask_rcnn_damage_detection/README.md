# Mask R-CNN for Car Damage Detection

This repo uses the Mask RCNN model from Matterport to train a custom model for detection damage on the cars. See example of detection below:

![alt text](https://github.com/priya-dwivedi/Deep-Learning/blob/master/mask_rcnn_damage_detection/results/combined.jpg)

I have also written a blog that goes into more details on how I trained a custom model. Please see it at the link below:



